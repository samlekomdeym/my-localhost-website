<?php
phpinfo();
?>
